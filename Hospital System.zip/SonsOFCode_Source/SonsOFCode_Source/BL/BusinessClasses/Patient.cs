﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace SonsOFCode_Source.BL.BusinessClasses
{
   public class Patient
    {
        public int ID
        {
            get;
            set;
        }

        public int QueForBooking
        {
            get;
            set;
        }
        public DateTime DateCreated
        {
            get;
            set;
        }

        public DateTime DOB
        {
            get;
            set;

        }

        public string Lastname
        {
            get;
            set;
        }

        public string HospitalBookedIn
        {
            get;
            set;
        }

        public string PatientMedicalAid
        {
            get;
            set;
        }

        public string ProcedureForPatient
        {
            get;
            set;
        }
        public DateTime BookInTime
        {
            get;
            set;
        }

        public DateTime BookOutTime
        {
            get;
            set;
        }

        public double FinCodes
        {
            get;
            set;
        }

        public double ModCodes
        {
            get;
            set;
        }
        public string Initials { get; internal set; }
    }
}
