﻿using SonsOFCode_Source.BL.BusinessClasses;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SonsOFCode_Source.BL.BusinessCustomCollections
{
   public class Notes : CollectionBase
    {

        //indexer

        public Note this[int noteIndex]
        {
            get
            {
                return 
                    (Note)List[noteIndex];
            }
            set
            {
                List[noteIndex] = value;
            }
        }
        public void AddNewNote(Note newNote)
        {
            if (newNote != null)
            {
                List.Add(newNote);
            }
        }

        public void RemoveOldNote(Note oldNote)
        {
            if (oldNote != null)
            {
                List.RemoveAt(oldNote.ID);
            }
        }
    }
}
