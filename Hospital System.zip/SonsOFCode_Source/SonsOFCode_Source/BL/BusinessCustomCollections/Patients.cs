﻿using SonsOFCode_Source.BL.BusinessClasses;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SonsOFCode_Source.BL.BusinessCustomCollections
{
  public class Patients : CollectionBase
    {
       

        public Patient this[int patientIndex]
        {
            get
            {
                return
                    (Patient)List[patientIndex];
            }
            set
            {
                List[patientIndex] = value;
            }
        }
        public void AddNewPatient(Patient newPatient)
        {
            if (newPatient != null)
            {
                List.Add(newPatient);
            }
            
           
        }

        public void RemoveOldPatient(Patient oldPatient)
        {
            if (oldPatient != null)
            {
                List.RemoveAt(oldPatient.ID);
            }
        }
    }
}
