﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SonsOFCode_Source.DAL;
using System.Threading.Tasks;
using SonsOFCode_Source.BL.BusinessCustomCollections;
using SonsOFCode_Source.BL.BusinessClasses;

namespace SonsOFCode_Source.BL
{
   public class SonsofCodeBusinessClass
    {
        private SonsOfCodeProviderBase sonsProviderType;
        private SonsOfCodeErrorProviderBase sonsProviderLog;

        public SonsofCodeBusinessClass(string sonsProviderString)
        {
            SetUpProvider(sonsProviderString);
        }

        public Notes SelectNotes()
        {
            return sonsProviderType.SelectNotes();
        }

        public BL.BusinessCustomCollections.Patients SelectAllPatients()
        {
            return sonsProviderType.SelectPatients();
        }

        public int InsertNewNote(Note note)
        {
            return sonsProviderType.InserNewtNote(note);
        }

        public  int InserNewPatient(Patient newPatient)
        {
            return sonsProviderType.InsertNewPatient(newPatient);
        }

        public int UpdateExistingNote(Note existingNote)
        {
            return sonsProviderType.UpdateExistingNote(existingNote);
        }

        public  int UpdateExistingPatient(Patient exisitingPatient)
        {
            return sonsProviderType.UpdateExistingPatient(exisitingPatient);
        }

        public int DeleteOldNote(Note oldNote)
        {
            return sonsProviderType.DeleteOldNote(oldNote);
        }

        public int DeleteOldPatient(Patient oldPatient)
        {
            return sonsProviderType.DeleteOldPatient(oldPatient);
        }


        public int InseretNewLogger(Logger newLogger)
        {
            return sonsProviderLog.InsertError(newLogger);
        }
        public List<Logger> SelectAllErrors(string filePath)
        {
            return sonsProviderLog.SelectAllErrors(filePath);
        }

        public List<Logger> SelectAllErrors(string filePath,int valueForCall)
        {
            return sonsProviderLog.SelectAllErrors(filePath);
        }


    

    public void SetUpProvider(string Prov)
        {
            if (Prov.Equals("SonsOfCodeSQLProvider"))
            {
                sonsProviderType = new SonsOfCodeSQLProvider();
            }
            else
            {
                if(Prov.Equals("SonsOfCodeLogXMLProvider"))
                sonsProviderLog = new SonsOfCodeLogXMLProvider();
            }
        }
    }
}
