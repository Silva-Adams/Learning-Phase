﻿using SonsOFCode_Source.BL.BusinessClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SonsOFCode_Source.DAL
{
   public abstract class SonsOfCodeErrorProviderBase
    {
        public abstract List<Logger> SelectAllErrors(string path);
        public abstract List<Logger> SelectAllErrors(string path, int value);

        public abstract int InsertError(Logger error);
    }
}
