﻿
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SonsOFCode_Source.BL.BusinessClasses;
using System.Xml;
using System;

namespace SonsOFCode_Source.DAL
{
    public class SonsOfCodeLogXMLProvider : SonsOfCodeErrorProviderBase
    {

        private string dataStore = "C:\\DataStores\\SonsOfCode\\";
        private XmlNode root; //Represents the root node
        private XmlDocument xDoc;

        public override List<Logger> SelectAllErrors(string filePath)
        {

            List<Logger> errorList = new List<Logger>();
            try
            {
                int retCode = 0;
                XmlNodeList nodeList;
                Logger eObj;

                // errorList = // this ensures that if there are no records,
                // the returned list will not be null, but
                // it will be empty (Count = 0)
                dataStore += filePath;
                retCode = loadDataStore();
                if (retCode == 0) // Success
                {
                    nodeList = root.SelectNodes("Log");
                    //
                    //
                    // NOTE: other pre-test loops also valid, but foreach is the safest option
                    //
                    //
                    foreach (XmlNode nodeRef in nodeList)
                    {
                        eObj = convertNodeToErrorObj(nodeRef);
                        errorList.Add(eObj);
                    } // end foreach
                } // end if
                else
                {
                    if (retCode == -1)
                    {
                        //ohk = new CustomDialogOK();
                        //ohk.SetMessage("No Logs generated!");
                        //ohk.Show();
                    } // end if
                } // end else
            } // end try
            catch (Exception ex)
            {
                //ohk = new CustomDialogOK();
                ex.ToString();
                
                
                //ohk.Show();
            } // end catch
            return errorList; // Single return
        }


        public override int InsertError(Logger error)
        {
            
            int rc = 0;

            try
            {
                int rcFindErrorNode = 0;
                int rcLoadDoc = 0;

                XmlNode eNode = null;
                XmlElement eElement;

                
                XmlElement eDate;
                XmlElement eType;
             
                XmlElement eDescription;

               
                XmlText eDateText;
                XmlText eTypeText;
             
                XmlText eDescriptionText;


                rcLoadDoc = loadDataStore();
                if (rcLoadDoc == 0)
                {
                    rcFindErrorNode = findErrorNode(error.Date, ref eNode);

                    if (rcFindErrorNode == -1)
                    {
                       
                        eElement = xDoc.CreateElement("Log");
                        eDate = xDoc.CreateElement("Date");
                        eType = xDoc.CreateElement("Type");
                        eDescription = xDoc.CreateElement("Description");
                    

                      
                        eDateText = xDoc.CreateTextNode(error.Date);
                        eTypeText = xDoc.CreateTextNode(error.Type);
                        eDescriptionText = xDoc.CreateTextNode(error.Description);
                  

                     
                        eDate.AppendChild(eDateText);
                        eType.AppendChild(eTypeText);
                        eDescription.AppendChild(eDescriptionText);
                      

                     
                        eElement.AppendChild(eDate);
                        eElement.AppendChild(eType);
                        eElement.AppendChild(eDescription);
                   

                       
                        root.AppendChild(eElement);
                        xDoc.Save(dataStore);
                    } // end if
                    else
                    {
                        rc = -1;
                    } // end else
                }// end if
                else
                {
                  
                    throw new Exception("Insert(): " + dataStore + " does not exist (not found)");
                } // end else
            } // end try
            catch (Exception ex)
            {
                throw ex;
            } // end catch
            return rc;  // Single return
        }
        private int loadDataStore()
        {
           

            int rc = 0;

            try
            {
                if (System.IO.File.Exists(dataStore))
                {

                    xDoc = new XmlDocument();
                    xDoc.Load(dataStore);
                    root = xDoc.SelectSingleNode("Logs");
                } // end if
                else
                {

                    rc = -1; // File not found
                } // end else
            } // end try
            catch (Exception ex)
            {
                throw ex;
            } // end catch
            return rc; // Single return
        } // end method
        private int loadDataStore(string path)
        {
          

            int rc = 0;

            try
            {
                if (System.IO.File.Exists(path))
                {

                    xDoc = new XmlDocument();
                    xDoc.Load(path);
                    root = xDoc.SelectSingleNode("Logs");
                } // end if
                else
                {

                    rc = -1; // File not found
                } // end else
            } // end try
            catch (Exception ex)
            {
                throw ex;
            } // end catch
            return rc; // Single return
        } // end method

        public override List<Logger> SelectAllErrors(string filePath, int valueToDeclared)
        {
            List<Logger> errorList = new List<Logger>();
            try
            {
                int retCode = 0;
                XmlNodeList nodeList;
                Logger eObj;

                // errorList = // this ensures that if there are no records,
                // the returned list will not be null, but
                // it will be empty (Count = 0)

                retCode = loadDataStore(filePath);
                if (retCode == 0) // Success
                {
                    nodeList = root.SelectNodes("Log");
                    //
                    //
                    // NOTE: other pre-test loops also valid, but foreach is the safest option
                    //
                    //
                    foreach (XmlNode nodeRef in nodeList)
                    {
                        eObj = convertNodeToErrorObj(nodeRef);
                        errorList.Add(eObj);
                    } // end foreach
                } // end if
                else
                {
                    if (retCode == -1)
                    {


                        //ohk = new CustomDialogOK();
                        //ohk.SetMessage("No Logs generated!");
                        //ohk.Show();
                    } // end if
                } // end else
            } // end try
            catch (Exception ex)
            {
                //ohk = new CustomDialogOK();
                ex.ToString();
                //ohk.Show();
            } // end catch
            return errorList; // Single return
        }


        private Logger convertNodeToErrorObj(XmlNode errorNode)
        {
            Logger errorObj;
            try
            {

                errorObj = new Logger();
                errorObj.Date = errorNode.SelectSingleNode("Date").InnerText;
                errorObj.Type = errorNode.SelectSingleNode("Type").InnerText;
                errorObj.Description = errorNode.SelectSingleNode("Description").InnerText;

            } 
            catch (Exception ex)
            {
                throw ex;
            } 
            return errorObj;
        }

        private int findErrorNode(string date, ref XmlNode errorNode)
        {
            //
            //Method name : int findSubjectNode(string Name, ref XmlNode subjectNode)
            //Purpose     : Try to find the user supplied Subject in XML data store
            //Re-use      : 
            //Input       : - string code
            //                - the code for the Subject that must be searched for in the XML document
            //              - ref XmlNode subjectNode
            //                - if the Subject node is found, it will be sent back via this method parameter
            //Output      : - int
            //                0 : Subject found
            //                -1: Subject not found
            //                -2: XML data store not loaded

            int rc;  // will be returned, thus can not be declared in try block

            try
            {
                if (xDoc != null)
                {
                    errorNode = root.SelectSingleNode("Log[Date='" + date + "']");
                    if (errorNode != null)
                    {
                        rc = 0; // Success
                    } // end if
                    else
                    {
                        rc = -1; // Not found
                    } // end else
                } // end if
                else
                {
                    rc = -2; // XML document not loaded
                } // end else
            } // end try
            catch (Exception ex)
            {
                throw ex;
            } // end catch
            return rc; // Single return
        } // end metho
    }
}
