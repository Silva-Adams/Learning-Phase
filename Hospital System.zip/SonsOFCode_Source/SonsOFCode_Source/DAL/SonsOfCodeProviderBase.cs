﻿using SonsOFCode_Source.BL.BusinessClasses;
using SonsOFCode_Source.BL.BusinessCustomCollections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SonsOFCode_Source.DAL
{
    public abstract class SonsOfCodeProviderBase
    {
        public abstract Notes SelectNotes();
        public abstract BL.BusinessCustomCollections.Patients SelectPatients();

        public  abstract int InserNewtNote(Note newNote);
        public abstract int InsertNewPatient(Patient newPatient);

        public abstract int UpdateExistingNote(Note existingNote);
        public abstract int UpdateExistingPatient(Patient exisitingPatient);

        public abstract int DeleteOldNote(Note oldNote);
        public abstract int DeleteOldPatient(Patient oldPatient);


        
    }
}
