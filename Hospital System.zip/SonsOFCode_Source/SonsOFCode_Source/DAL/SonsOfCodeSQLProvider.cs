﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SonsOFCode_Source.BL.BusinessClasses;
using SonsOFCode_Source.BL.BusinessCustomCollections;
using System.Data.SQLite;
using System.Data;

namespace SonsOFCode_Source.DAL
{
    public class SonsOfCodeSQLProvider : SonsOfCodeProviderBase
    {
        private string connectionString = "Data Source = c:\\DataStores\\SonsOfCode\\SonsOfCode.s3db;Version=3;";
        private SQLiteConnection sqlConnection;


        public override Notes SelectNotes()
        {
            Notes notesFromDB;
            try
            {
                sqlConnection = new SQLiteConnection(connectionString);
                bool readSuccess = false;
                notesFromDB = new Notes();
                sqlConnection.Open();

                string selectQuery = "SELECT * FROM Notes";
                SQLiteCommand sqlCommand = new SQLiteCommand(selectQuery, sqlConnection);
                SQLiteDataReader reader = sqlCommand.ExecuteReader();
                readSuccess = reader.Read();
                while (readSuccess)
                {

                    Note note = new Note();
                    note.ID = Convert.ToInt32(reader["ID"]);
                    note.Username = Convert.ToString(reader["Username"]);
                    note.DateCreated = Convert.ToDateTime(reader["DateCreated"]);
                    note.PatientName = Convert.ToString(reader["PatientName"]);
                    note.DescrptionForNote = Convert.ToString(reader["DescrptionForNote"]);
                    notesFromDB.AddNewNote(note);

                    readSuccess = reader.Read();

                }


            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                sqlConnection.Close();
            }

            return notesFromDB;
        }

        public override BL.BusinessCustomCollections.Patients SelectPatients()
        {
            BL.BusinessCustomCollections.Patients patientsFromDB = null;
            try
            {
                sqlConnection = new SQLiteConnection(connectionString);
                bool readSuccess = false;
                patientsFromDB = new  BL.BusinessCustomCollections.Patients(); 
                sqlConnection.Open();

                string selectQuery = "SELECT * FROM Patients";
                SQLiteCommand sqlCommand = new SQLiteCommand(selectQuery, sqlConnection);
                SQLiteDataReader reader = sqlCommand.ExecuteReader();
                readSuccess = reader.Read();
                while (readSuccess)
                {
                    Patient patient = new Patient();
                    patient.ID = Convert.ToInt32(reader["ID"]);
                    patient.DateCreated = Convert.ToDateTime(reader["DateCreated"]);
                    patient.QueForBooking = Convert.ToInt32(reader["QueForBooking"]);
                    patient.HospitalBookedIn = Convert.ToString(reader["HospitalBookedIn"]);
                    patient.DOB = Convert.ToDateTime(reader["DOB"]);
                    patient.Lastname = Convert.ToString(reader["Lastname"]);
                    patient.Initials = Convert.ToString(reader["Initials"]);
                    patient.PatientMedicalAid = Convert.ToString (reader["PatientMedicalAid"]);
                    patient.ProcedureForPatient = Convert.ToString(reader["ProcedureForPatient"]);
                    patient.BookInTime = Convert.ToDateTime(reader["BookInTime"]);
                    patient.BookOutTime = Convert.ToDateTime(reader["BookOutTime"]);
                    patient.ModCodes = Convert.ToInt64(reader["ModCodes"]);
                    patient.FinCodes = Convert.ToInt64(reader["FinCodes"]);
                    patientsFromDB.AddNewPatient(patient);

                    readSuccess = reader.Read();

                }


            }
            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                sqlConnection.Close();
            }

            return patientsFromDB;
        }
        public override int DeleteOldNote(Note oldNote)
        {
            int rc = 0;



            try
            {
                int rowsAffected = 0;
                sqlConnection = new SQLiteConnection(connectionString);
                sqlConnection.Open();

                string deleteQuery = string.Format("DELETE FROM Notes WHERE [ID] = '{0}'", oldNote.ID);
                SQLiteCommand sqlCommand = new SQLiteCommand(deleteQuery, sqlConnection);
                rowsAffected = sqlCommand.ExecuteNonQuery();

                if (rowsAffected == 0)
                {
                    rc = -1;

                }
                else
                {
                    rc = 0;

                }
            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                sqlConnection.Close();
            }
            return rc;
        }

        public override int DeleteOldPatient(Patient oldPatient)
        {
            int rc = 0;



            try
            {
                int rowsAffected = 0;
                sqlConnection = new SQLiteConnection(connectionString);
                sqlConnection.Open();

                string deleteQuery = string.Format("DELETE FROM Patients WHERE [ID] = '{0}'", oldPatient.ID);
                SQLiteCommand sqlCommand = new SQLiteCommand(deleteQuery, sqlConnection);
                rowsAffected = sqlCommand.ExecuteNonQuery();

                if (rowsAffected == 0)
                {
                    rc = -1;

                }
                else
                {
                    rc = 0;

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConnection.Close();
            }


            return rc;
        }

        public override int InserNewtNote(Note newNote)
        {
            int rc = 1;

            try
            {
                sqlConnection = new SQLiteConnection(connectionString);

                sqlConnection.Open();

                string insertQuery = "INSERT INTO Notes([Username],[DateCreated],[PatientName],[DescrptionForNote])" +
                    " VALUES(@Username,@DateCreated,@PatientName,@DescrptionForNote)";
                SQLiteCommand sqlComm = new SQLiteCommand(insertQuery, sqlConnection);

                SQLiteParameter[] sqlParameters = new SQLiteParameter[]
                {



                      new SQLiteParameter("@Username", DbType.String),
                      new SQLiteParameter("@DateCreated", DbType.DateTime),
                      new SQLiteParameter("@PatientName", DbType.String),
                      new SQLiteParameter("@DescrptionForNote", DbType.String),

                };

                sqlParameters[0].Value = newNote.Username;
                sqlParameters[1].Value = newNote.DateCreated;
                sqlParameters[2].Value = newNote.PatientName;
                sqlParameters[3].Value = newNote.DescrptionForNote;
             


                sqlComm.Parameters.AddRange(sqlParameters);

                int rowsAffected = sqlComm.ExecuteNonQuery();

                if (rowsAffected == 1)
                {
                    rc = 0;
                }
            }

            catch (SQLiteException ex)
            {
                if (ex.ErrorCode == SQLiteErrorCode.Constraint)
                {
                    rc = -1;


                }
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                sqlConnection.Close();
            }

            return rc;
        }

        public override int InsertNewPatient(Patient newPatient)
        {
            int rc = 1;

            try
            {
                sqlConnection = new SQLiteConnection(connectionString);

                sqlConnection.Open();

                string insertQuery = "INSERT INTO Patients([DateCreated],[QueForBooking],[HospitalBookedIn],[DOB],[Lastname],[Initials],[PatientMedicalAid]," +
                       "[ProcedureForPatient],[BookInTime],[BookOutTime],[FinCodes],[ModCodes]) VALUES(@DateCreated,@QueForBooking,@HospitalBookedIn,@DOB,@Lastname,@Initials,@PatientMedicalAid,@ProcedureForPatient,@BookInTime,@BookOutTime,@FinCodes,@ModCodes)";
                SQLiteCommand sqlComm = new SQLiteCommand(insertQuery, sqlConnection);
                SQLiteParameter[] sqlParameters = new SQLiteParameter[]
                             {

                                
                  new SQLiteParameter("@DateCreated", DbType.DateTime),
                  new SQLiteParameter("@QueForBooking", DbType.Int32),
                  new SQLiteParameter("@HospitalBookedIn", DbType.String),
                  new SQLiteParameter("@DOB", DbType.DateTime),
                  new SQLiteParameter("@Lastname", DbType.String),
                  new SQLiteParameter("@Initials", DbType.String),
                  new SQLiteParameter("@PatientMedicalAid", DbType.String),
                  new SQLiteParameter("@ProcedureForPatient", DbType.String),
                  new SQLiteParameter("@BookInTime", DbType.DateTime),
                  new SQLiteParameter("@BookOutTime", DbType.DateTime),
                  new SQLiteParameter("@FinCodes", DbType.Int64),
                  new SQLiteParameter("@ModCodes", DbType.Int64),

                             };

                sqlParameters[0].Value = newPatient.DateCreated;
                sqlParameters[1].Value = newPatient.QueForBooking;
                sqlParameters[2].Value = newPatient.HospitalBookedIn;
                sqlParameters[3].Value = newPatient.DOB;
                sqlParameters[4].Value = newPatient.Lastname;
                sqlParameters[5].Value = newPatient.Initials;
                sqlParameters[6].Value = newPatient.PatientMedicalAid;
                sqlParameters[7].Value = newPatient.ProcedureForPatient;
                sqlParameters[8].Value = newPatient.BookInTime;
                sqlParameters[9].Value = newPatient.BookOutTime;
                sqlParameters[10].Value = newPatient.FinCodes;
                sqlParameters[11].Value = newPatient.ModCodes;

                sqlComm.Parameters.AddRange(sqlParameters);
               

                int rowsAffected = sqlComm.ExecuteNonQuery();

                if (rowsAffected == 1)
                {

                    rc = 0;


                }

            }

            catch (SQLiteException ex)
            {
                if (ex.ErrorCode == SQLiteErrorCode.Constraint)
                {
                    rc = -1;


                }
            }
            catch (Exception exception)
            {

                throw exception;
            }
            finally
            {
                sqlConnection.Close();
            }

            return rc;
        }

      

        public override int UpdateExistingNote(Note existingNote)
        {
            int rc = 1;

            try
            {
                sqlConnection = new SQLiteConnection(connectionString);

                sqlConnection.Open();



                string updateQuery = string.Format("UPDATE Notes SET [Username] = @Username,[DateCreated] = @DateCreated,[PatientName] = @PatientName,[DescrptionForNote] = @DescrptionForNote WHERE [ID] = '{0}'", existingNote.ID);
                SQLiteCommand sqlComm = new SQLiteCommand(updateQuery, sqlConnection);

                SQLiteParameter[] sqlParameters = new SQLiteParameter[]
                {



                      new SQLiteParameter("@Username", DbType.String),
                      new SQLiteParameter("@DateCreated", DbType.DateTime),
                      new SQLiteParameter("@PatientName", DbType.String),
                      new SQLiteParameter("@DescrptionForNote", DbType.String),

                };


                sqlParameters[0].Value = existingNote.Username;
                sqlParameters[1].Value = existingNote.DateCreated;
                sqlParameters[2].Value = existingNote.PatientName;
                sqlParameters[3].Value = existingNote.DescrptionForNote;


                sqlComm.Parameters.AddRange(sqlParameters);

                int rowsAffected = sqlComm.ExecuteNonQuery();

                if (rowsAffected == 1)
                {

                    rc = 0;
                }

                {
                    rowsAffected = -1;
                }

            }


            catch (Exception exception)
            {

                throw exception;
            }
            finally
            {
                sqlConnection.Close();
            }

            return rc;

        }

        public override int UpdateExistingPatient(Patient exisitingPatient)
        {
            int rowsAffected = 1;
            try
            {

                sqlConnection = new SQLiteConnection(connectionString);
                sqlConnection.Open();
                string updateQuery = String.Format("UPDATE Patients SET [DateCreated] = @DateCreated,[QueForBooking] = @QueForBooking,[HospitalBookedIn] = @HospitalBookedIn," +
                      "[DOB] = @DOB,[Lastname] = @Lastname,[Initials] = @Initials,[PatientMedicalAid] = @PatientMedicalAid,[ProcedureForPatient] = @ProcedureForPatient,[BookInTime] = @BookInTime,[BookOutTime] = @BookOutTime,[FinCodes] = @FinCodes,[ModCodes] = @ModCodes WHERE [ID] = '{0}'", exisitingPatient.ID);
                SQLiteCommand sqlCommand = new SQLiteCommand(updateQuery, sqlConnection);

                SQLiteParameter[] sqlParameters = new SQLiteParameter[]
                {


                  new SQLiteParameter("@DateCreated", DbType.DateTime),
                  new SQLiteParameter("@QueForBooking", DbType.Int32),
                  new SQLiteParameter("@HospitalBookedIn", DbType.String),
                  new SQLiteParameter("@DOB", DbType.DateTime),
                  new SQLiteParameter("@Lastname", DbType.String),
                  new SQLiteParameter("@Initials", DbType.String),
                  new SQLiteParameter("@PatientMedicalAid", DbType.String),
                  new SQLiteParameter("@ProcedureForPatient", DbType.String),
                  new SQLiteParameter("@BookInTime", DbType.DateTime),
                  new SQLiteParameter("@BookOutTime", DbType.DateTime),
                  new SQLiteParameter("@FinCodes", DbType.Int64),
                  new SQLiteParameter("@ModCodes", DbType.Int64),

                };

                sqlParameters[0].Value = exisitingPatient.DateCreated;
                sqlParameters[1].Value = exisitingPatient.QueForBooking;
                sqlParameters[2].Value = exisitingPatient.HospitalBookedIn;
                sqlParameters[3].Value = exisitingPatient.DOB;
                sqlParameters[4].Value = exisitingPatient.Lastname;
                sqlParameters[5].Value = exisitingPatient.Initials;
                sqlParameters[6].Value = exisitingPatient.PatientMedicalAid;
                sqlParameters[7].Value = exisitingPatient.ProcedureForPatient;
                sqlParameters[8].Value = exisitingPatient.BookInTime;
                sqlParameters[9].Value = exisitingPatient.BookOutTime;
                sqlParameters[10].Value = exisitingPatient.FinCodes;
                sqlParameters[11].Value = exisitingPatient.ModCodes;

                sqlCommand.Parameters.AddRange(sqlParameters);
                rowsAffected = sqlCommand.ExecuteNonQuery();

                if (rowsAffected == 1)
                {
                    rowsAffected = 0;
                }
                else
                {
                    rowsAffected = -1;
                }

            }
            catch (Exception exception)
            {
                throw exception;
            }
            finally
            {
                sqlConnection.Close();
            }
            return rowsAffected;
        }
    }
}
