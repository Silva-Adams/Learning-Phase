﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace SonsOFCode_Source
{
    /// <summary>
    /// Interaction logic for Documentation.xaml
    /// </summary>
    public partial class Documentation : Page
    {
        public Documentation()
        {
            InitializeComponent();
        }
        private void listPdf_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            string app = Environment.CurrentDirectory;
            string pdf = System.IO.Path.Combine(app, "c:\\DataStores\\SonsOfCode\\Software Requirements Definition\\Software Requirements Definition.pdf");
            PDFV.Navigate(new System.Uri(pdf));
        }

        private void UGD_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            string app = Environment.CurrentDirectory;
            string pdf = System.IO.Path.Combine(app, "c:\\DataStores\\SonsOfCode\\User Guide\\User Manual.pdf");
            PDFV.Navigate(new System.Uri(pdf));
        }
        //private void Install_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        //{
        //    string app = Environment.CurrentDirectory;
        //    string pdf = System.IO.Path.Combine(app, "c:\\DataStores\\SonsOfCode\\User Guide\\Installation Manual.pdf");
        //    PDFV.Navigate(new System.Uri(pdf));
        //}
    }
    }
