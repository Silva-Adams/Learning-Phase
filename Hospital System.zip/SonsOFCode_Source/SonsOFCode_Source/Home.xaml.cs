﻿using System.Windows;
using System.Windows.Controls;

namespace SonsOFCode_Source
{
    /// <summary>
    /// Interaction logic for Home.xaml
    /// </summary>
    public partial class Home : Page
    {
        public Home()
        {
            InitializeComponent();
        }

        private void BtnGroupInfo_Click(object sender, RoutedEventArgs e)
        {
            Main.Content = new GroupInfo();
        }

        private void BtnExit_Click(object sender, RoutedEventArgs e)
        {
            Application.Current.Shutdown(99);
        }

    }
}
