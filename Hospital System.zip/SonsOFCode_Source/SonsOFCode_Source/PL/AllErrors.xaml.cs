﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SonsOFCode_Source.BL;
using SonsOFCode_Source.BL.BusinessClasses;

namespace SonsOFCode_Source.PL
{
    /// <summary>
    /// Interaction logic for AllErrors.xaml
    /// </summary>
    public partial class AllErrors : Page
    {
        SonsofCodeBusinessClass loggertype = new SonsofCodeBusinessClass("SonsOfCodeLogXMLProvider");
        private string dataStore = "C:\\DataStores\\SonsOfCode\\";
        public AllErrors()
        {
            InitializeComponent();
        }

        private void listView_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            List<Logger> loggers;
            try
            {
                loggers = loggertype.SelectAllErrors(dataStore);
                lstFileDetails.DataContext = loggers;

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
