﻿using SonsOFCode_Source.BL;
using SonsOFCode_Source.BL.BusinessClasses;
using SonsOFCode_Source.BL.BusinessCustomCollections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SonsOFCode_Source.PL
{
    /// <summary>
    /// Interaction logic for AllNotes.xaml
    /// </summary>
    public partial class AllNotes : Page
    {
        SonsofCodeBusinessClass businessClass;
        Notes notes;
        public AllNotes()
        {
            InitializeComponent();
            businessClass = new SonsofCodeBusinessClass("SonsOfCodeSQLProvider");
        } 

        private void btnCreateNote_Click(object sender, RoutedEventArgs e)
        {
            listNotes.Visibility = Visibility.Hidden;
            hospitalFrame.Content = new NotesCRUD();
        }

        private void btnUpdateNote_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Note existingNote = listNotes.SelectedItem as Note;
                if (existingNote.Equals(null) || existingNote.Equals(""))
                {
                    MessageBox.Show("Select Note to Update");
                }
                else
                {
                    listNotes.Visibility = Visibility.Hidden;
                    hospitalFrame.Content = new NotesCRUD(existingNote);
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                MessageBox.Show("Select Note to Update");
            }
        }

        private void btnDeleteNote_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Note oldNote = listNotes.SelectedItem as Note;
                if (oldNote.Equals(null) || oldNote.Equals(""))
                {
                    MessageBox.Show("Select Patient to Delete");
                }
                else
                {
                    listNotes.Visibility = Visibility.Hidden;
                    int deleteExistingPatient = businessClass.DeleteOldNote(oldNote);
                    if (deleteExistingPatient == 0)
                    {
                        MessageBox.Show("Deleted Successfully!");
                    }
                    else
                    {
                        MessageBox.Show("Could not Delete Patient");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Select Patient to Delete");
                MessageBox.Show(ex.Message);
            }
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            try
            {
                notes = businessClass.SelectNotes();
                listNotes.DataContext = notes;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
