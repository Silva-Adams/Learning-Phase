﻿using SonsOFCode_Source.BL;
using SonsOFCode_Source.BL.BusinessClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SonsOFCode_Source.PL
{
    /// <summary>
    /// Interaction logic for AllPatients.xaml
    /// </summary>
    public partial class AllPatients : Page
    {
        SonsofCodeBusinessClass businessClass;
        BL.BusinessCustomCollections.Patients patientsList;
        public AllPatients()
        {
            businessClass = new SonsofCodeBusinessClass("SonsOfCodeSQLProvider");
            InitializeComponent();
        }

        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            patientsList = businessClass.SelectAllPatients();
            listPatients.DataContext = patientsList;         
        }

        private void btnCreatePatient_Click(object sender, RoutedEventArgs e)
        {
            listPatients.Visibility = Visibility.Hidden;
            hospitalFrame.Content = new PatientCRUD();
        }

        private void btnUpdatePatient_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Patient existingPatient = listPatients.SelectedItem as Patient;
                if (existingPatient.Equals(null) || existingPatient.Equals(""))
                {
                    MessageBox.Show("Select Patient to Update");
                }
                else
                {
                    listPatients.Visibility = Visibility.Hidden;
                    hospitalFrame.Content = new PatientCRUD(existingPatient);
                }
            }
            catch (Exception ex)
            {
                ex.ToString();
                MessageBox.Show("Select Patient to Update");
            }
         
        }

        private void btnDeletePatient_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Patient oldPatient = listPatients.SelectedItem as Patient;
                if (oldPatient.Equals(null) || oldPatient.Equals(""))
                {
                    MessageBox.Show("Select Patient to Delete");
                }
                else
                {
                    listPatients.Visibility = Visibility.Hidden;
                    int deleteExistingPatient = businessClass.DeleteOldPatient(oldPatient);
                    if (deleteExistingPatient == 0)
                    {
                        MessageBox.Show("Deleted Successfully!");
                    }
                    else
                    {
                        MessageBox.Show("Could not Delete Patient");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Select Patient to Delete");
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSeePatients_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
