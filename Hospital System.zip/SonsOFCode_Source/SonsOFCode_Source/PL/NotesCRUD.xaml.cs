﻿using SonsOFCode_Source.BL;
using SonsOFCode_Source.BL.BusinessClasses;
using SonsOFCode_Source.BL.BusinessCustomCollections;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SonsOFCode_Source.PL
{
    /// <summary>
    /// Interaction logic for NotesCRUD.xaml
    /// </summary>
    public partial class NotesCRUD : Page
    {
        SonsofCodeBusinessClass businessClass;
        Notes Notes;
        Note existingGlobalNote;

        public NotesCRUD()
        {
            businessClass = new SonsofCodeBusinessClass("SonsOfCodeSQLProvider");
            InitializeComponent();
            btnSaveNote.Visibility = Visibility.Visible;
            btnUpdateNote.Visibility = Visibility.Hidden;
            PopulateComboControl();
         
        }

        public void PopulateComboControl()
        {
            try
            {
                BL.BusinessCustomCollections.Patients patients = businessClass.SelectAllPatients();
                comboLastnames.Items.Clear();
                foreach (Patient patientLastname in patients)
                {
                    comboLastnames.Items.Add(patientLastname.Lastname as string);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           
        }
        public NotesCRUD(Note existingNote)
        {
            InitializeComponent();
            businessClass = new SonsofCodeBusinessClass("SonsOfCodeSQLProvider");
            existingGlobalNote = existingNote;
            PopulateControls();
            PopulateComboControl();
            btnSaveNote.Visibility = Visibility.Hidden;
            btnUpdateNote.Visibility = Visibility.Visible;
         
        }

        public void PopulateControls()
        {
            txtUsername.Text = existingGlobalNote.Username;
            PopulateComboControl();
            txtNoteDescription.Text = existingGlobalNote.DescrptionForNote;
        }

        private void btnSaveNote_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                Note note = new Note();
                if (ValidateControls())
                {
                    note.DateCreated = DateTime.Now;
                    note.Username = txtUsername.Text;
                    note.PatientName = comboLastnames.SelectedItem as string;
                    note.DescrptionForNote = txtNoteDescription.Text;

                    int add = businessClass.InsertNewNote(note);
                    if (add == 0)
                    {
                        MessageBox.Show("Note Added successfully!");
                    }
                    else
                    {
                        MessageBox.Show("Could not add Note");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           
            
        }

        private void btnUpdateNote_Click(object sender, RoutedEventArgs e)
        {
            if (ValidateControls())
            {
                existingGlobalNote.DateCreated = DateTime.Now;
                existingGlobalNote.Username = txtUsername.Text;
                existingGlobalNote.PatientName = comboLastnames.SelectedItem as string;
                existingGlobalNote.DescrptionForNote = txtNoteDescription.Text;

                int update = businessClass.UpdateExistingNote(existingGlobalNote);
                if (update == 0)
                {
                    MessageBox.Show("Note Updated successfully!");
                }
                else
                {
                    MessageBox.Show("Could not update Note");
                }
            }
            else
            {
                MessageBox.Show("Validation Errors:" + "\n" +
                   "Enter all fields and provide date Values");
            }
        }

        public bool ValidateControls()
        {
            if (txtUsername.Text.Length == 0 || txtNoteDescription.Text.Length == 0 || comboLastnames.Text.Length == 0)
            {
                return false;
            }
            else
            { return true; }
            
            
        }
    }
}
