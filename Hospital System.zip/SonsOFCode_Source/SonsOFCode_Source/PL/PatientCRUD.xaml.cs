﻿using SonsOFCode_Source.BL;
using SonsOFCode_Source.BL.BusinessClasses;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SonsOFCode_Source.PL
{
    /// <summary>
    /// Interaction logic for PatientCRUD.xaml
    /// </summary>
    public partial class PatientCRUD : Page
    {
        List<int> ques = new List<int>();
        List<string> hospitals = new List<string>();
        int retC;
        SonsofCodeBusinessClass businessClass;
        Patient existingGlobalPatient;

        public PatientCRUD()
        {
            InitializeComponent();
            btnSavePatient.Visibility = Visibility.Visible;
            btnUpdatePatient.Visibility = Visibility.Hidden;
            
            businessClass = new SonsofCodeBusinessClass("SonsOfCodeSQLProvider");
        }

        public PatientCRUD(Patient existingPatient)
        {
            InitializeComponent();
            existingGlobalPatient = existingPatient;
            PopulateControls();
            btnSavePatient.Visibility = Visibility.Hidden;
            btnUpdatePatient.Visibility = Visibility.Visible;
            businessClass = new SonsofCodeBusinessClass("SonsOfCodeSQLProvider");
        }

        public void PopulateControls()
        {
            txtLastname.Text = existingGlobalPatient.Lastname;
            txtInitials.Text = existingGlobalPatient.Initials;
            txtMedicalAid.Text = existingGlobalPatient.PatientMedicalAid;
            txtProcedure.Text = existingGlobalPatient.ProcedureForPatient;
            txtModeCodes.Text = existingGlobalPatient.ModCodes.ToString();
            txtFineCodes.Text = existingGlobalPatient.FinCodes.ToString();
            pickerDateofBirth.Text = existingGlobalPatient.DOB.ToString();
            pickerBookIn.Text = existingGlobalPatient.BookInTime.ToString();
            pickerBookOut.Text = existingGlobalPatient.BookOutTime.ToString();
            
        }
        private void Page_Loaded(object sender, RoutedEventArgs e)
        {
            for (int i = 1; i < 32; i++)
            {
                ques.Add(i);
                comboQue.Items.Add(i);
            }

            hospitals.Add("Medi-Clinic");
            hospitals.Add("Penelope");
            hospitals.Add("Oppenheimer");
            for (int i = 0; i < hospitals.Count; i++)
            {
                ques.Add(i);
                comboHospital.Items.Add(hospitals[i]);
            }



        }

        private bool ValidateControlsInputs()
        {
            bool isValid = false;
            if (txtLastname.Text.Length == 0 || txtInitials.Text.Length == 0 || txtMedicalAid.Text.Length == 0
                || txtProcedure.Text.Length == 0 || txtMedicalAid.Text.Length == 0 ||txtModeCodes.Text.Length == 0 ||
                txtFineCodes.Text.Length == 0 || comboQue.Text.Length == 0 || comboHospital.Text.Length == 0 || pickerBookIn.Text.Length == 0 
                || pickerDateofBirth.Text.Length == 0  || pickerBookOut.Text.Length == 0)
            {
                isValid = false;
            }
            else
            {
                isValid = true;
            }

            return isValid;
        }

        private void btnSavePatient_Click(object sender, RoutedEventArgs e)
        {
            if (ValidateControlsInputs())
            {
                Patient newPatient = new Patient();
                newPatient.QueForBooking = (int)comboQue.SelectedItem;
                newPatient.DateCreated = DateTime.Now;
                newPatient.DOB = Convert.ToDateTime(pickerDateofBirth.Text);
                newPatient.Lastname = txtLastname.Text;
                newPatient.Initials = txtInitials.Text;
                newPatient.HospitalBookedIn = (string)comboHospital.SelectedItem;
                newPatient.PatientMedicalAid = txtMedicalAid.Text;
                newPatient.ProcedureForPatient = txtProcedure.Text;
                newPatient.BookInTime = Convert.ToDateTime(pickerBookIn.Text);
                newPatient.BookOutTime = Convert.ToDateTime(pickerBookOut.Text);
                newPatient.FinCodes = Convert.ToInt64(txtFineCodes.Text);
                newPatient.ModCodes = Convert.ToInt64(txtModeCodes.Text);

                retC = businessClass.InserNewPatient(newPatient);
                if (retC == 0)
                {
                    MessageBox.Show("Patient added Successfully!");
                }
                else
                {
                    MessageBox.Show("Could not add A new Patient");
                }


            }
            else
            {
                MessageBox.Show("Validation Errors:" + "\n" +
                    "Enter all fields and provide date Values");
            }
        }

        private void btnUpdatePatient_Click(object sender, RoutedEventArgs e)
        {
            if (ValidateControlsInputs())
            {
              
                existingGlobalPatient.QueForBooking = (int)comboQue.SelectedItem;
                existingGlobalPatient.DateCreated = DateTime.Now;
                existingGlobalPatient.DOB = Convert.ToDateTime(pickerDateofBirth.Text);
                existingGlobalPatient.Lastname = txtLastname.Text;
                existingGlobalPatient.Initials = txtInitials.Text;
                existingGlobalPatient.HospitalBookedIn = (string)comboHospital.SelectedItem;
                existingGlobalPatient.PatientMedicalAid = txtMedicalAid.Text;
                existingGlobalPatient.ProcedureForPatient = txtProcedure.Text;
                existingGlobalPatient.BookInTime = Convert.ToDateTime(pickerBookIn.Text);
                existingGlobalPatient.BookOutTime = Convert.ToDateTime(pickerBookOut.Text);
                existingGlobalPatient.FinCodes = Convert.ToInt64(txtFineCodes.Text);
                existingGlobalPatient.ModCodes = Convert.ToInt64(txtModeCodes.Text);

                retC = businessClass.UpdateExistingPatient(existingGlobalPatient);
                if (retC == 0)
                {
                    MessageBox.Show("Patient Updated Successfully!");
                }
                else
                {
                    MessageBox.Show("Could not add update an existing  Patient");
                }


            }
            else
            {
                MessageBox.Show("Validation Errors:" + "\n" +
                    "Enter all fields and provide date Values");
            }
        }
    }
}
